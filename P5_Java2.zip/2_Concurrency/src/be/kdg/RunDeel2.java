package be.kdg;

import be.kdg.concurrency.Persoon;
import be.kdg.concurrency.PersoonCallable;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
/*
 * 2de zit examen Java2 - 18/08/2016
 */
public class RunDeel2 {
    private static List<Persoon> personen = Arrays.asList(
            new Persoon("Eric Buelens", Persoon.Geslacht.MAN, 1984, 2510.24),
            new Persoon("Patrick Devos", Persoon.Geslacht.MAN, 1967, 2140.21),
            new Persoon("Els Callens", Persoon.Geslacht.VROUW, 1974, 1478.91),
            new Persoon("Dorien Vanderpoorten", Persoon.Geslacht.VROUW, 1994, 1487.35),
            new Persoon("Fred Somers", Persoon.Geslacht.MAN, 1965, 3140.84),
            new Persoon("Floor Custers", Persoon.Geslacht.VROUW, 1989, 2541.92),
            new Persoon("Griet Op de Beeck", Persoon.Geslacht.VROUW, 1976, 2368.11),
            new Persoon("Lucas Van de Ven", Persoon.Geslacht.MAN, 1972, 3472.44)
    );

    public static void main(String[] args) throws Exception {
        // TODO: Aan te vullen - mannen (2.2)


        // TODO: Aan te vullen  - vrouwen (2.2).


        // TODO: Aan te vullen  (2.3)

    }
}

/*
Mannen:
Fred Somers            MAN 1965 €3140,84
Patrick Devos          MAN 1967 €2140,21
Lucas Van de Ven       MAN 1972 €3472,44
Eric Buelens           MAN 1984 €2510,24

Vrouwen
Els Callens          VROUW 1974 €1478,91
Griet Op de Beeck    VROUW 1976 €2368,11
Floor Custers        VROUW 1989 €2541,92
Dorien Vanderpoorten VROUW 1994 €1487,35

Gemiddeld loon mannen:  €2815,93
Gemiddeld loon vrouwen: €1969,07
 */