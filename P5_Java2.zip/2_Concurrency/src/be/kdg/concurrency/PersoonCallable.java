package be.kdg.concurrency;

import java.util.List;
import java.util.concurrent.Callable;

/*
 * 2de zit examen Java2 - 18/08/2016
 */
public class PersoonCallable {
    private List<Persoon> personen;

    public PersoonCallable(List<Persoon> personen) {
        this.personen = personen;
    }

    // TODO aanvullen (2.1)

}
