package be.kdg.patterns;

import java.util.ArrayList;
import java.util.List;

/*
 * 2de zit examen Java2 - 18/08/2016
 */

public class Verzameling {
    // TODO Vul aan (4.1)

}
