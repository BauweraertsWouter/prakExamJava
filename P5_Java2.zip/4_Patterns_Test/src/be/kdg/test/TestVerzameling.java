package be.kdg.test;

// imports bewust verwijderd

/*
 * 2de zit examen Java2 - 18/08/2016
 */

// TODO Te schrijven klasse (4.4)
public class TestVerzameling {

}
