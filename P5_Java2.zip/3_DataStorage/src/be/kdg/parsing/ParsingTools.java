package be.kdg.parsing;

import be.kdg.model.Foto;
import be.kdg.model.PortFolio;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.List;

/*
 * 2de zit examen Java2 - 18/08/2016
 */

public class ParsingTools {

    // TODO Te schrijven methode (3.1)
    public static void maakXML(List<Foto> fotoList, String fileName) {

    }

    // TODO Te schrijven methode (3.2)
    public static List<Foto> leesXML(String fileName) {

        return null;
    }
}
