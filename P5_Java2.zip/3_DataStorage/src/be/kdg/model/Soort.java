package be.kdg.model;

/**
 *  HIER MAG JE NIETS WIJZIGEN
 */
public enum Soort {
    ACTION, PORTRAIT
}
